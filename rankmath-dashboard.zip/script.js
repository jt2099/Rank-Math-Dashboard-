document.addEventListener('DOMContentLoaded', function () {
  // Navigation buttons
  const buttons = document.querySelectorAll('nav ul li button');
  const sections = document.querySelectorAll('.toolSection');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const target = btn.id.replace('Btn', '');
      sections.forEach(section => {
        section.classList.remove('active');
        if(section.id === target) {
          section.classList.add('active');
        }
      });
    });
  });

  // Default active
  document.getElementById('seoAnalysisBtn').classList.add('active');
  document.getElementById('seoAnalysis').classList.add('active');

  // SEO Analysis Tool
  const analyzeBtn = document.getElementById('analyzeBtn');
  analyzeBtn.addEventListener('click', () => {
    const content = document.getElementById('seoContent').value.trim();
    const result = document.getElementById('seoResult');
    if(!content) {
      result.textContent = 'Please enter some content to analyze.';
      return;
    }
    // Simple SEO checks: word count, keyword density (basic example)
    const words = content.split(/\s+/);
    const wordCount = words.length;
    const keyword = prompt('Enter a keyword to check density:', '');
    if(!keyword) {
      result.textContent = 'Keyword check skipped.';
      return;
    }
    const keywordCount = words.filter(w => w.toLowerCase() === keyword.toLowerCase()).length;
    const density = ((keywordCount / wordCount) * 100).toFixed(2);
    result.innerHTML = \`<p>Word count: <b>\${wordCount}</b></p>
                        <p>Keyword "<b>\${keyword}</b>" count: <b>\${keywordCount}</b></p>
                        <p>Keyword density: <b>\${density}%</b></p>\`;
  });

  // Sitemap Generator Tool
  const sitemapBtn = document.getElementById('generateSitemapBtn');
  sitemapBtn.addEventListener('click', () => {
    const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://example.com/</loc><changefreq>daily</changefreq><priority>1.0</priority></url>
  <url><loc>https://example.com/about</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>
  <url><loc>https://example.com/contact</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>
</urlset>`;
    document.getElementById('sitemapResult').textContent = sitemapXml;
  });

  // Schema Markup Tool
  const pageTypeSelect = document.getElementById('pageType');
  const faqInputs = document.getElementById('faqInputs');
  const addFaqBtn = document.getElementById('addFaq');
  let faqCount = 1;

  pageTypeSelect.addEventListener('change', () => {
    if(pageTypeSelect.value === 'FAQPage') {
      faqInputs.style.display = 'block';
    } else {
      faqInputs.style.display = 'none';
    }
  });

  addFaqBtn.addEventListener('click', () => {
    faqCount++;
    const qInput = document.createElement('input');
    qInput.type = 'text';
    qInput.name = 'question' + faqCount;
    qInput.placeholder = 'Question ' + faqCount;
    const aInput = document.createElement('input');
    aInput.type = 'text';
    aInput.name = 'answer' + faqCount;
    aInput.placeholder = 'Answer ' + faqCount;
    faqInputs.insertBefore(document.createElement('br'), addFaqBtn);
    faqInputs.insertBefore(qInput, addFaqBtn);
    faqInputs.insertBefore(aInput, addFaqBtn);
  });

  const schemaForm = document.getElementById('schemaForm');
  schemaForm.addEventListener('submit', e => {
    e.preventDefault();
    const pageType = pageTypeSelect.value;
    if(!pageType) {
      alert('Please select a page type');
      return;
    }
    let jsonLd = {};
    if(pageType === 'FAQPage') {
      let mainEntity = [];
      for(let i = 1; i <= faqCount; i++) {
        const q = schemaForm['question' + i];
        const a = schemaForm['answer' + i];
        if(q && a && q.value.trim() && a.value.trim()) {
          mainEntity.push({
            "@type": "Question",
            "name": q.value.trim(),
            "acceptedAnswer": {
              "@type": "Answer",
              "text": a.value.trim()
            }
          });
        }
      }
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": mainEntity
      };
    } else if(pageType === 'Article') {
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Example Article",
        "author": "Rank Math Clone",
        "datePublished": "2025-06-07"
      };
    }
    document.getElementById('schemaResult').textContent = JSON.stringify(jsonLd, null, 2);
  });

  // Redirection Manager
  const redirectForm = document.getElementById('redirectForm');
  const redirectList = document.getElementById('redirectList');
  let redirects = [];

  redirectForm.addEventListener('submit', e => {
    e.preventDefault();
    const oldUrl = document.getElementById('oldUrl').value.trim();
    const newUrl = document.getElementById('newUrl').value.trim();
    if(!oldUrl || !newUrl) return;
    redirects.push({oldUrl, newUrl});
    updateRedirectList();
    redirectForm.reset();
  });

  function updateRedirectList() {
    redirectList.innerHTML = '';
    redirects.forEach((r, i) => {
      const li = document.createElement('li');
      li.textContent = \`\${r.oldUrl} → \${r.newUrl}\`;
      redirectList.appendChild(li);
    });
  }

  // Content AI (simple suggestions)
  const generateContentBtn = document.getElementById('generateContentBtn');
  const contentSuggestions = document.getElementById('contentSuggestions');

  generateContentBtn.addEventListener('click', () => {
    const keyword = document.getElementById('keywordInput').value.trim();
    contentSuggestions.innerHTML = '';
    if(!keyword) {
      contentSuggestions.innerHTML = '<li>Please enter a keyword.</li>';
      return;
    }
    // Dummy suggestions
    const suggestions = [
      \`How to use \${keyword} effectively\`,
      \`\${keyword} SEO best practices\`,
      \`Common mistakes in \${keyword}\`,
      \`Advanced tips for \${keyword}\`
    ];
    suggestions.forEach(s => {
      const li = document.createElement('li');
      li.textContent = s;
      contentSuggestions.appendChild(li);
    });
  });
});
